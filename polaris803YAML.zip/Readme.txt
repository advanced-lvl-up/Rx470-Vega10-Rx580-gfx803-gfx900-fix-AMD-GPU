the actual templates of 'polaris' and 'r9nano' are just the same, renamed for convenience.

The 'polaris' and 'r9nano' folder from this archive goes into whatever directory you specify for your build command,  For example:
C:\ROCM\rocBLAS-rocm-6.2.4\library\src\blas3\Tensile\Logic\asm_full\    (or whichever path you chose)

it will look for C:\ROCM\rocBLAS-rocm-6.2.4\library\src\blas3\Tensile\Logic\asm_full\polaris\polaris_Cijk_Ailk_Bjlk_SB.yaml
and all other similarly named contractions for compiling the default templates

-------------------------------------------------------------------------------

in c:\Rocm\Tensile-rocm-6.2.4\tensile\common.py near line 301 you can change
  'all':'_','gfx000':'none', 'gfx803':'r9nano', 'gfx900':'vega10', 'gfx900:xnack-':'vega10',

 to something like this for simplicity's sake:
  'all':'_','gfx000':'none', 'gfx803':'polaris', 'gfx900':'vega10', 'gfx900:xnack-':'vega10',

But either should work.  Let me know if I got it wrong. Note:  It's all very incomplete, fp16, bf16, fp32, and other common ones should be fine (for most common tasks and strides), but the others are untested.   For example, just basic diffusion tasks in ComfyUI should work on 90% of common model architectures.  Beyond that it's uncharted territory.







