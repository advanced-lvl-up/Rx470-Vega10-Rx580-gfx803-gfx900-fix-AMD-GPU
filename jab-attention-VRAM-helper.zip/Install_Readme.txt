## Instructions:  File explorer -> navigate to  yourpath/ComfyUI/comfy/ldm/modules/  and make a copy backup of the file named 'attention.py'
## Now edit the 'attention.py' with basic notepad or a code editor.  Somewhere Near line 212, you should see '@wrap_attn' and 'def attention_sub_quad():' 
## It's about 70 lines and it ends with the line 'return hidden_states'.
## Create a new line break there, and copy paste our custom code block, 2 lines below. 
## In this zip file is ready-made 'example_attention.py' which you can review for reference, in case something goes wrong. 
## Now our 2nd definition simply overrides the first.   But you should learn to do it yourself for future Comfy versions.  (in case you update Comfy)
##
## Just restore the backup of your original 'attention.py' if you need to start over again.
## Confirm and save the edited file, then restart both the console and webUI.  That should be all.
## The --use-quad-cross-attention argument will now use Jab-atttention with no additional changes.
## If successful you'll see  "Custom Attention function is enabled." in the command console on your first generation, along with some stats.


## Jab-attention function for better VRAM management begins here:  
## jabberwocky attention: This is random code used to test CPUs a long time ago, torch.matmul seems better on CPU.  works fine with zluda as well.
jw_cached_tokens = 0   # DiT Global tokens cache
@wrap_attn
def attention_sub_quad(q, k, v, heads: int, mask=None, attn_precision=None, skip_reshape=False, **kwargs):
    global jw_cached_tokens    # instead of calling the sub_quad function, we'll handle the calculations directly as follows:
    if not skip_reshape:
        B, T, C = q.shape
        Dh = C // heads
        q = q.view(B, T, heads, Dh).transpose(1, 2).contiguous()
        k = k.view(B, k.shape[1], heads, Dh).transpose(1, 2).contiguous()
        v = v.view(B, v.shape[1], heads, Dh).transpose(1, 2).contiguous()
    B, H, T, Dh = q.shape

    head_tile_size = 16
    tile_size = 1024    # and use multiples of 256 here, (the optimal values are lost in my archives somewhere, we'll try guessing or deriving from KV)

    jw_cached_tokens += 1
    if jw_cached_tokens == 1:
        print(" Custom Attention function is enabled.  Tiling parameters:", head_tile_size, tile_size)   # Debug print example.

    q = q * float(Dh) ** -0.50    # scaling factor has interesting effects. (example -0.48 hallucination and mosaics, -0.52 more stable but less motion)
    # If you change the parameters just remember to set them back to defaults, as the default is generally good.

    out = torch.empty((B, H, T, Dh), dtype=q.dtype, device=q.device)
    def _tile_loop(q, k, v, out):
        for h_start in range(0, H, head_tile_size):
            h_end = min(h_start + head_tile_size, H)
            q_h = q[:, h_start:h_end]
            k_h = k[:, h_start:h_end]
            v_h = v[:, h_start:h_end]
            out_h = out[:, h_start:h_end]

            for t_start in range(0, T, tile_size):
                t_end = min(t_start + tile_size, T)
                q_t = q_h[:, :, t_start:t_end]
                out_t = torch.matmul(q_t, k_h.transpose(-2, -1))    # it's possible to fuse matmul and softmax ops here, thats more difficult without CUDA
                out_t = torch.softmax(out_t, dim=-1)
                out_t = torch.matmul(out_t, v_h)
                out_h[:, :, t_start:t_end].copy_(out_t, non_blocking=True)
    _tile_loop(q, k, v, out)

    return out.transpose(1, 2).reshape(B, T, heads * Dh)   # End of jabberwocky attention.  Returning expected values